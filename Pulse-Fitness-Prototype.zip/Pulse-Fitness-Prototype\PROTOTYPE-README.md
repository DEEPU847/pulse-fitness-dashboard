﻿# Pulse Fitness prototype

## Run it

Requirements: Node.js 20+ and npm.

1. Extract this ZIP.
2. Open a terminal in the extracted `client` folder.
3. Run `npm install`.
4. Run `npm run dev -- --host 0.0.0.0`.
5. Open the local URL printed by Vite (usually http://localhost:5173).

The app runs in local demo mode by default. No MongoDB, API server, or Google OAuth setup is required.

## Demo sign-in

- Email: `demo@pulse.fit`
- Password: `pulse1234`

You can also create an account from the sign-in page. Demo accounts, workouts, and goals are stored in that browser's local storage. They are not shared between browsers or devices.

The `client/dist` folder contains the prebuilt production site for static hosting. The source is included under `client/src`.
